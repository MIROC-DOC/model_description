#!/bin/csh
#           gtool3 ascii -> binary
#
if ($#argv < 2) then
	echo 'usage: gta2u ascii-file gt3-file [format]'
	exit
endif
if ($#argv == 2) then
	set form = '(5G12.5)'
else
	set form = "($3)"
endif
#
set tf = /tmp/gtu2a.$$
echo $1 > $tf
echo $form >> $tf
echo $2 >> $tf
echo UR >> $tf
BINDIR/trnsgt < $tf
rm $tf
