#!/bin/csh
#           gtool3 binary -> ascii
#
if ($#argv < 2) then
	echo 'usage: gtu2a gt3-file ascii-file [format]'
	exit
endif
if ($#argv == 2) then
	set form = '(5G12.5)'
else
	set form = "($3)"
endif
#
set tf = /tmp/gtu2a.$$
echo $1 > $tf
echo UR >> $tf
echo $2 >> $tf
echo $form >> $tf
BINDIR/trnsgt < $tf
rm $tf
